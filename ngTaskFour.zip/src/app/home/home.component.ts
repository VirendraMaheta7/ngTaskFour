import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProviderService } from '../provider.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

addDeptForm : FormGroup;
  @ViewChild ('deptModal') deptModal : ModalDirective;

  constructor(private fb: FormBuilder, private provider : ProviderService) { }

  ngOnInit() {
    this.initEmpForm();
  }
  openDept(){
    this.deptModal.show();
  }
  closeDeptModal(){
    this.deptModal.hide();
  }
  initEmpForm(){
    this.addDeptForm = this.fb.group({
      deptName : ['', Validators.required]
    })
  }
  submitDept(){
    if(this.addDeptForm.valid){
       let dept = this.addDeptForm.value.deptName;
      for (let index = 0; index < this.provider.lstDepartment.length; index++) {
 
        if(this.provider.lstDepartment[index].deptName == dept){
          alert("Already!")
        }else{
          this.provider.lstDepartment.push(this.addDeptForm.value);
           return;
           
          }
        }
        console.log(this.provider.lstDepartment);
 
      this.addDeptForm.reset();
      this.deptModal.hide();
     }else{
      alert("Invalid form")
    }
    
  }
}
